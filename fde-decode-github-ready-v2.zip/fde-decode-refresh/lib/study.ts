export const SUBJECTS = [
  { slug: 'biology', name: 'Biology', short: 'Living systems, cells, ecology and the human body', icon: 'dna', accent: 'mint', visual: 'Cells, systems and life cycles' },
  { slug: 'physics', name: 'Physics', short: 'Motion, forces, energy, waves and electricity', icon: 'atom', accent: 'blue', visual: 'Motion graphs and force models' },
  { slug: 'computer-science', name: 'Computer Science', short: 'Algorithms, programming, data and computational thinking', icon: 'code', accent: 'violet', visual: 'Flowcharts and logic maps' },
  { slug: 'chemistry', name: 'Chemistry', short: 'Atoms, bonding, reactions and materials', icon: 'flask', accent: 'orange', visual: 'Molecular and particle models' },
  { slug: 'english', name: 'English', short: 'Grammar, reading, vocabulary and writing', icon: 'book', accent: 'rose', visual: 'Sentence structures and word maps' },
  { slug: 'mathematics', name: 'Mathematics', short: 'Number, algebra, geometry, graphs and reasoning', icon: 'sigma', accent: 'blue', visual: 'Worked steps and mathematical graphs' },
  { slug: 'urdu', name: 'Urdu', short: 'قواعد، تفہیم، تحریر، ادب اور ذخیرۂ الفاظ', icon: 'pen', accent: 'mint', visual: 'Grammar maps and literature notes' },
  { slug: 'islamiat', name: 'Islamiat', short: 'Islamic beliefs, values, history and practice', icon: 'moon', accent: 'violet', visual: 'Concept maps and timelines' },
  { slug: 'mutalia-quran', name: 'Mutalia Quran', short: 'Quranic themes, vocabulary and reflection', icon: 'book-open', accent: 'orange', visual: 'Theme maps and key vocabulary' },
] as const;

export type SubjectSlug = (typeof SUBJECTS)[number]['slug'];
export type StudyMode = 'tutor' | 'visual' | 'quiz' | 'flashcards' | 'formula' | 'notes' | 'sticky';
export type StudyCard = { front: string; back: string };
export type QuizQuestion = {
  question: string;
  options: string[];
  answer: number;
  explanation: string;
  scenario?: string;
};

export const CLASS_LEVELS = Array.from({ length: 11 }, (_, index) => `Class ${index + 1}`);
export const LANGUAGES = ['Simple English', 'Urdu', 'Roman Urdu'] as const;

export function getSubjectBySlug(slug: string) {
  return SUBJECTS.find((subject) => subject.slug === slug);
}

export function getSubjectName(slug: string) {
  return getSubjectBySlug(slug)?.name ?? 'Biology';
}

export function slugToSubject(slug: string) {
  return getSubjectName(slug);
}
