import StudyWorkspace from '@/components/StudyWorkspace';
export default function Flashcards() { return <StudyWorkspace mode="flashcards" initialSubject="Biology" />; }
