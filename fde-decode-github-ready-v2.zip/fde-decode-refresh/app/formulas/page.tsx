import StudyWorkspace from '@/components/StudyWorkspace';
export default function QuickReference() { return <StudyWorkspace mode="formula" initialSubject="Mathematics" />; }
