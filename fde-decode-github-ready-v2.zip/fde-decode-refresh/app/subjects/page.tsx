import SectionTitle from '@/components/SectionTitle';
import SubjectCards from '@/components/SubjectCards';

export default function Subjects() {
  return (
    <main className="page-wrap inner-page">
      <SectionTitle eyebrow="SUBJECT LIBRARY · CLASSES 1–11" title="Choose a subject. Explore any topic." description="Open a subject, enter the topic you want to learn, choose your class and language, and let the AI build an explanation, examples and practice material." />
      <div className="notice-card"><b>How it works</b><span>Tap a subject card to open its own workspace. Topic explanations, visuals, quizzes and flashcards each have separate tools and inputs.</span></div>
      <SubjectCards />
      <p className="source-note">The AI generates learning support from your topic prompt. It is not currently connected to a verified searchable database of every official textbook or syllabus.</p>
    </main>
  );
}
