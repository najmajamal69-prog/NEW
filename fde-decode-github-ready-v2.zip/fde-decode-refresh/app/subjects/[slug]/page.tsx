import { notFound } from 'next/navigation';
import StudyWorkspace from '@/components/StudyWorkspace';
import { getSubjectBySlug } from '@/lib/study';

export default async function SubjectPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const subject = getSubjectBySlug(slug);
  if (!subject) notFound();
  return <StudyWorkspace key={subject.slug} mode="tutor" initialSubject={subject.name} lockedSubject />;
}
