import StudyWorkspace from '@/components/StudyWorkspace';
export default function StickyNotesPage() { return <StudyWorkspace mode="sticky" initialSubject="Physics" />; }
