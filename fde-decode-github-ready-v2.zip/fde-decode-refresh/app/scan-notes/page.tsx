'use client';
import { useState } from 'react';
import { Camera, Upload, Sparkles, BookOpen, AlertCircle, CheckCircle2, Mic, Square, AudioLines } from 'lucide-react';
import { motion } from 'framer-motion';
import { CLASS_LEVELS, LANGUAGES, SUBJECTS } from '@/lib/study';

export default function ScanNotesPage() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState('');
  const [subject, setSubject] = useState('Physics');
  const [classLevel, setClassLevel] = useState('Class 9');
  const [language, setLanguage] = useState('Simple English');
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [recording, setRecording] = useState(false);
  const [voiceText, setVoiceText] = useState('');
  const [voiceBusy, setVoiceBusy] = useState(false);
  const [voiceError, setVoiceError] = useState('');
  const [recorder, setRecorder] = useState<MediaRecorder | null>(null);
  const [chunks, setChunks] = useState<Blob[]>([]);
  function selectFile(next?: File) {
    if (!next) return;
    if (!next.type.startsWith('image/')) { setError('Please choose an image.'); return; }
    if (next.size > 10 * 1024 * 1024) { setError('Image must be under 10 MB.'); return; }
    setFile(next); setPreview(URL.createObjectURL(next)); setData(null); setError('');
  }
  async function startVoiceNote() {
    setVoiceError(''); setVoiceText('');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const media = new MediaRecorder(stream); const parts: Blob[] = [];
      media.ondataavailable = event => { if (event.data.size) parts.push(event.data); };
      media.onstop = async () => {
        stream.getTracks().forEach(track => track.stop());
        const blob = new Blob(parts, { type: media.mimeType || 'audio/webm' });
        const form = new FormData(); form.append('audio', blob, 'voice-note.webm');
        setVoiceBusy(true);
        try { const response = await fetch('/api/voice-note', { method: 'POST', body: form }); const payload = await response.json(); if (!response.ok) throw new Error(payload.error || 'Transcription failed.'); setVoiceText(payload.text || 'No speech was detected.'); }
        catch (e) { setVoiceError(e instanceof Error ? e.message : 'Could not transcribe audio.'); }
        finally { setVoiceBusy(false); }
      };
      media.start(); setRecorder(media); setRecording(true);
    } catch { setVoiceError('Please allow microphone access in your browser, then try again.'); }
  }
  function stopVoiceNote() { if (recorder && recorder.state !== 'inactive') { recorder.stop(); setRecording(false); setRecorder(null); } }

  async function analyze() {
    if (!file) { setError('Capture or upload a page of handwritten notes first.'); return; }
    setLoading(true); setError(''); setData(null);
    try {
      const form = new FormData(); form.append('image', file); form.append('subject', subject); form.append('classLevel', classLevel); form.append('language', language);
      const response = await fetch('/api/scan-notes', { method: 'POST', body: form });
      const payload = await response.json();
      if (!response.ok || !payload.data) throw new Error(payload.error || 'Analysis failed.');
      setData(payload.data);
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not analyze the image.'); }
    finally { setLoading(false); }
  }
  return <main className="page-wrap inner-page workspace-page">
    <motion.section className="workspace-hero" initial={{opacity:0,y:12}} animate={{opacity:1,y:0}}>
      <div className="workspace-hero-copy"><span className="eyebrow"><Camera size={14}/> AI HANDWRITING SCANNER</span><h1>Turn your notes into <span>clear understanding.</span></h1><p>Capture a page or upload a photo. AI will transcribe the visible writing, explain it in simpler words and organize revision notes.</p><div className="workspace-assurance"><span className="assurance-dot"/> Unclear handwriting is flagged instead of silently guessed</div></div>
      <div className="workspace-hero-art" aria-hidden="true"><div className="workspace-art-orbit orbit-a"/><div className="workspace-art-orbit orbit-b"/><div className="workspace-art-core"><Camera size={40}/></div><span className="workspace-art-chip chip-a">Scan</span><span className="workspace-art-chip chip-b">Understand</span></div>
    </motion.section>
    <section className="scan-layout">
      <div className="scan-upload-card">
        <h2 className="text-xl font-extrabold">1. Add your notes photo</h2><p className="mb-5 mt-2 text-sm leading-6 text-[#7e867d]">Use good lighting, keep the page flat and include the full writing area.</p>
        <label className="scan-dropzone">{preview ? <img src={preview} alt="Notes photo preview" className="scan-preview"/> : <><Upload size={30} className="text-[#39815D]"/><b>Choose photo or open camera</b><span className="text-xs text-[#858C83]">JPG, PNG or WEBP · max 10 MB</span></>}<input type="file" accept="image/*" capture="environment" className="hidden" onChange={e=>selectFile(e.target.files?.[0])}/></label>
        <div className="mt-5 grid gap-3 sm:grid-cols-3"><label className="text-sm font-semibold">Subject<select className="mt-2 w-full rounded-xl border border-[#e5e5dc] bg-white p-3" value={subject} onChange={e=>setSubject(e.target.value)}>{SUBJECTS.map(x=><option key={x.slug}>{x.name}</option>)}</select></label><label className="text-sm font-semibold">Class<select className="mt-2 w-full rounded-xl border border-[#e5e5dc] bg-white p-3" value={classLevel} onChange={e=>setClassLevel(e.target.value)}>{CLASS_LEVELS.map(x=><option key={x}>{x}</option>)}</select></label><label className="text-sm font-semibold">Language<select className="mt-2 w-full rounded-xl border border-[#e5e5dc] bg-white p-3" value={language} onChange={e=>setLanguage(e.target.value)}>{LANGUAGES.map(x=><option key={x}>{x}</option>)}</select></label></div>
        <button onClick={analyze} disabled={!file||loading} className="button button-primary mt-5 w-full justify-center disabled:opacity-50">{loading?'Reading your notes…':<> <Sparkles size={17}/> Analyze notes with AI</>}</button>
        {error&&<p className="mt-4 flex gap-2 rounded-xl bg-[#fff0eb] p-3 text-sm leading-6 text-[#a4422c]"><AlertCircle size={18} className="shrink-0"/>{error}</p>}
      </div>
      <div className="scan-upload-card mt-5">
        <span className="eyebrow"><AudioLines size={14}/> VOICE NOTES</span>
        <h2 className="mb-2 mt-2 text-2xl font-black">Speak your question or class notes</h2>
        <p className="mb-4 text-sm leading-6 text-[#7e867d]">Record a short voice note. AI will convert speech to text so you can review or copy it into your study notes.</p>
        <div className="flex flex-wrap gap-3">
          {!recording ? <button className="button button-primary" onClick={startVoiceNote} disabled={voiceBusy}><Mic size={17}/> {voiceBusy ? 'Transcribing…' : 'Start voice note'}</button> : <button className="button button-secondary" onClick={stopVoiceNote}><Square size={16}/> Stop & transcribe</button>}
        </div>
        {voiceError && <p className="mt-3 rounded-xl bg-[#fff0eb] p-3 text-sm text-[#a4422c]">{voiceError}</p>}
        {voiceText && <div className="mt-4 rounded-2xl border border-[#e5e5dc] bg-[#f8faf5] p-4"><b className="mb-2 block">Transcribed voice note</b><p className="whitespace-pre-wrap leading-7">{voiceText}</p><button className="button button-ghost mt-3" onClick={()=>navigator.clipboard?.writeText(voiceText)}>Copy text</button></div>}
      </div>
      <div className="scan-upload-card"><span className="eyebrow">WHAT YOU'LL GET</span><h2 className="mb-5 mt-2 text-2xl font-black">From handwriting to revision-ready notes</h2>{[['Faithful transcription','Read the text visible in your photo'],['Easy explanation','Understand the same material in simpler words'],['Organized notes','Headings, bullet points and key terms'],['Revision questions','Check what you understood']].map(([title,desc])=><div key={title} className="mb-4 flex gap-3 rounded-2xl bg-[#f6f8f2] p-4"><CheckCircle2 className="mt-1 shrink-0 text-[#39815D]"/><div><b>{title}</b><p className="mt-1 text-sm leading-6 text-[#7e867d]">{desc}</p></div></div>)}<p className="mt-5 text-xs leading-6 text-[#8a9187]">AI may misread handwriting, numbers or symbols. Always compare the transcription with your original page, especially for equations and textbook-specific facts.</p></div>
    </section>
    {data&&<motion.section className="workspace-results mt-8" initial={{opacity:0,y:12}} animate={{opacity:1,y:0}}><div className="results-heading"><div><span className="eyebrow">YOUR SCANNED NOTES</span><h2>{data.title||'Notes explained'}</h2></div><span className="ai-created-pill"><Sparkles size={14}/> AI assisted</span></div><article className="result-card mb-4"><span className="result-card-label">TRANSCRIBED TEXT</span><p className="scan-result">{data.extractedText||'No text was returned.'}</p></article><article className="result-card mb-4"><span className="result-card-label">EXPLAINED IN EASY WORDS</span><p className="scan-result">{data.simpleExplanation}</p></article><div className="smart-notes-grid">{(data.organizedNotes||[]).map((note:any,i:number)=><article key={i} className="result-card"><span className="result-card-label">STUDY NOTE {i+1}</span><h3 className="mb-3 mt-2 text-lg font-extrabold">{note.heading}</h3><ul className="result-list">{(note.points||[]).map((point:string,j:number)=><li key={j}><CheckCircle2 size={16}/><span>{point}</span></li>)}</ul></article>)}</div><article className="result-card mb-4"><span className="result-card-label">IMPORTANT TERMS</span>{(data.keyTerms||[]).map((x:any,i:number)=><div className="term-item" key={i}><b>{x.term}</b><p>{x.meaning}</p></div>)}</article>{(data.uncertainParts||[]).length>0&&<article className="result-card mb-4 border-[#f0dca2] bg-[#fff9e6]"><span className="result-card-label">PLEASE CHECK THESE PARTS</span><ul className="result-list">{data.uncertainParts.map((x:string,i:number)=><li key={i}><AlertCircle size={16}/><span>{x}</span></li>)}</ul></article>}<article className="result-card"><span className="result-card-label">REVISION QUESTIONS</span>{(data.revisionQuestions||[]).map((x:any,i:number)=><details key={i} className="mb-3 rounded-xl border border-[#ecebe4] p-4"><summary className="cursor-pointer font-bold">{x.question}</summary><p className="mt-3 leading-7 text-[#6f786e]">{x.answer}</p></details>)}</article></motion.section>}
  </main>;
}
