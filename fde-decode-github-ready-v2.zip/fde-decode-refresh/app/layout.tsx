import type { Metadata } from 'next';
import './globals.css';
import Navbar from '@/components/Navbar';
import ReviewPrompt from '@/components/ReviewPrompt';
import AuthGate from '@/components/AuthGate';

export const metadata: Metadata = {
  title: 'FDE Decode — Your AI Study Helper',
  description: 'Explore school topics with AI explanations, visual learning, 50-question quizzes, handwritten note scanning, sticky notes and flashcards for Classes 1–11.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <AuthGate><Navbar />{children}<ReviewPrompt /></AuthGate>
        <footer className="footer"><span className="brand-mark small">F</span><span>FDE Decode</span><span className="footer-note">Learn it. See it. Own it.</span></footer>
      </body>
    </html>
  );
}
