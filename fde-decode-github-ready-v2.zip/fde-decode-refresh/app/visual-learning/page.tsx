import StudyWorkspace from '@/components/StudyWorkspace';
export default function VisualLearning() { return <StudyWorkspace mode="visual" initialSubject="Physics" />; }
