'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowRight, BookOpen, BrainCircuit, Camera, CheckCircle2, FlaskConical, GraduationCap, Layers3, Sparkles, StickyNote, Target, WandSparkles, Zap } from 'lucide-react';
import SubjectCards from '@/components/SubjectCards';

const fade = { hidden: { opacity: 0, y: 18 }, show: { opacity: 1, y: 0, transition: { duration: 0.45 } } };

export default function Home() {
  return (
    <main className="page-wrap home-page">
      <section className="hero updated-home-hero">
        <div className="hero-copy">
          <div className="hero-badge"><Sparkles size={14} /> YOUR PERSONAL AI STUDY HELPER</div>
          <motion.h1 initial="hidden" animate="show" variants={fade}>Learn any topic.<br/><span>See the big picture.</span></motion.h1>
          <p className="hero-description">A flexible AI learning space for Classes 1–11. Explore subjects, understand concepts, build visuals, generate quizzes and practise with animated flashcards.</p>
          <div className="hero-actions">
            <Link href="/subjects" className="button button-primary">Explore subjects <ArrowRight size={17}/></Link>
            <Link href="/visual-learning" className="button button-ghost"><WandSparkles size={16}/> Open Visual Lab</Link>
          </div>
          <div className="hero-proof"><div className="avatar-stack"><span>A</span><span>I</span><span>+</span></div><span><b>Your topic, your level, your learning</b><small>Personalised explanations • Practice-ready tools</small></span></div>
        </div>
        <motion.div className="hero-visual" initial={{ opacity: 0, scale: 0.94 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.65 }}>
          <div className="orbit orbit-one"/><div className="orbit orbit-two"/>
          <div className="planet"><BrainCircuit size={76} strokeWidth={1.15}/></div>
          <div className="float-card float-card-top"><span className="mini-icon violet"><BookOpen size={17}/></span><span><b>Topic unlocked</b><small>Pick any subject</small></span><CheckCircle2 className="check-icon" size={17}/></div>
          <div className="float-card float-card-bottom"><span className="mini-icon orange"><Zap size={17}/></span><span><b>Smart practice</b><small>50-question quizzes</small></span><ArrowRight size={17}/></div>
          <div className="visual-caption"><span className="pulse-dot"/> YOUR LEARNING UNIVERSE</div>
        </motion.div>
      </section>

      <section className="stats-strip updated-stats-strip">
        <div><span className="stat-icon purple"><BookOpen size={18}/></span><span><b>Learn</b><small>Clear topic explanations</small></span></div>
        <div><span className="stat-icon green"><Target size={18}/></span><span><b>Practise</b><small>50-question quizzes</small></span></div>
        <div><span className="stat-icon orange"><Layers3 size={18}/></span><span><b>Remember</b><small>Animated flashcards</small></span></div>
        <div><span className="stat-icon blue"><FlaskConical size={18}/></span><span><b>Visualise</b><small>Dynamic topic diagrams</small></span></div>
      </section>

      <section className="content-section updated-subject-section">
        <div className="section-heading-row"><div><span className="eyebrow">YOUR LEARNING UNIVERSE</span><h2>Choose a subject</h2><p>Open any subject, enter your own topic, and generate learning material for your class.</p></div><Link className="text-link" href="/subjects">All subjects <ArrowRight size={16}/></Link></div>
        <SubjectCards />
      </section>

      <section className="updated-tools-section">
        <div className="section-heading-row"><div><span className="eyebrow">AI STUDY TOOLS</span><h2>One topic. Different ways to master it.</h2><p>Each tool has its own topic input and creates subject-specific material using AI.</p></div></div>
        <div className="tool-grid updated-tool-grid">
          <Link href="/visual-learning" className="tool-card tool-purple"><span className="tool-icon"><WandSparkles/></span><h3>Visual Lab</h3><p>Enter a topic and get a diagram, labels and a clear visual explanation.</p><span className="tool-bottom">Build a visual <ArrowRight size={15}/></span></Link>
          <Link href="/quizzes" className="tool-card tool-orange"><span className="tool-icon"><BrainCircuit/></span><h3>AI Quizzes</h3><p>Generate 50 scenario-based questions, check answers and learn from explanations.</p><span className="tool-bottom">Practise a topic <ArrowRight size={15}/></span></Link>
          <Link href="/flashcards" className="tool-card tool-green"><span className="tool-icon"><Layers3/></span><h3>Flashcards</h3><p>Make a new deck for any topic with smooth 3D flip and next-card animations.</p><span className="tool-bottom">Start recalling <ArrowRight size={15}/></span></Link>
          <Link href="/formulas" className="tool-card tool-blue"><span className="tool-icon"><GraduationCap/></span><h3>Quick Reference</h3><p>Get formulas, symbols and examples — or subject-appropriate rules and key ideas.</p><span className="tool-bottom">Build a reference <ArrowRight size={15}/></span></Link>
        </div>
      </section>

      <section className="feature-banner updated-feature-banner"><div className="feature-art"><div className="diagram-circle"><span/><span/><span/><span/></div><div className="diagram-label label-a">QUESTION</div><div className="diagram-label label-b">DISCOVER</div></div><div className="feature-copy"><span className="eyebrow">MADE AROUND YOUR QUESTION</span><h2>Don't see your topic? <em>Type it in.</em></h2><p>You are not limited to a preset chapter list. Open a subject or learning tool, enter the topic you want to learn, select a class from 1–11, and build material for that exact topic.</p><Link href="/subjects" className="button button-dark">Find your subject <ArrowRight size={16}/></Link></div></section>

      <section className="bottom-cta"><div><span className="eyebrow">START WITH CURIOSITY</span><h2>Your next question can become a lesson.</h2><p>Choose a subject, enter a topic, and start learning your way.</p></div><Link href="/subjects" className="button button-primary">Start learning <ArrowRight size={17}/></Link></section>
      <div className="homepage-disclaimer">AI-generated content is a learning aid and can make mistakes. Check important details against your textbook or teacher's guidance.</div>
    </main>
  );
}
