import OpenAI from 'openai';
import { NextResponse } from 'next/server';
import { SUBJECTS, CLASS_LEVELS, LANGUAGES } from '@/lib/study';

export const runtime = 'nodejs';
export const maxDuration = 60;

export async function POST(request: Request) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return NextResponse.json({ error: 'AI is not configured. Add OPENAI_API_KEY to your local .env.local and Netlify environment variables.' }, { status: 503 });
  try {
    const form = await request.formData();
    const file = form.get('image');
    const subjectRaw = String(form.get('subject') || 'Biology');
    const classRaw = String(form.get('classLevel') || 'Class 9');
    const languageRaw = String(form.get('language') || 'Simple English');
    if (!(file instanceof File)) return NextResponse.json({ error: 'Upload or capture an image first.' }, { status: 400 });
    if (!file.type.startsWith('image/')) return NextResponse.json({ error: 'Please upload an image file.' }, { status: 400 });
    if (file.size > 10 * 1024 * 1024) return NextResponse.json({ error: 'Image must be smaller than 10 MB.' }, { status: 413 });
    const subject = SUBJECTS.some((x) => x.name === subjectRaw) ? subjectRaw : 'Biology';
    const classLevel = CLASS_LEVELS.includes(classRaw) ? classRaw : 'Class 9';
    const language = (LANGUAGES as readonly string[]).includes(languageRaw) ? languageRaw : 'Simple English';
    const bytes = Buffer.from(await file.arrayBuffer());
    const dataUrl = `data:${file.type};base64,${bytes.toString('base64')}`;
    const client = new OpenAI({ apiKey });
    const response = await client.responses.create({
      model: process.env.OPENAI_VISION_MODEL || process.env.OPENAI_MODEL || 'gpt-4.1-mini',
      instructions: 'You are a careful school-note reader and tutor. Never pretend unclear handwriting is certain. Preserve the meaning of the original notes. If text is unreadable, mark it [unclear] and mention that the student should verify it against the original page. Do not invent missing words, equations, textbook facts, or religious references. Return only valid JSON.',
      input: [{ role: 'user', content: [
        { type: 'input_text', text: `Analyze this student's handwritten school-note image. Subject: ${subject}. Level: ${classLevel}. Explain in: ${language}. Return JSON with keys: title, extractedText (faithful transcription; use [unclear] where needed), simpleExplanation (explain the actual visible content in easy words), organizedNotes (array of objects with heading and points array), keyTerms (array of objects with term and meaning), uncertainParts (array of strings identifying any handwriting, symbols or words you could not confidently read), and revisionQuestions (array of 3 questions with answers). Do not add material that is not supported by the image unless clearly labelled as extra explanation.` },
        { type: 'input_image', image_url: dataUrl, detail: 'high' },
      ] }],
      text: { format: { type: 'json_object' } },
      max_output_tokens: 6000,
    });
    if (!response.output_text) throw new Error('The AI returned no analysis.');
    const parsed = JSON.parse(response.output_text.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, ''));
    return NextResponse.json({ data: parsed, meta: { subject, classLevel, language, reviewedAt: new Date().toISOString() } });
  } catch (error) {
    console.error('FDE Decode image analysis error:', error);
    return NextResponse.json({ error: 'Could not analyze this image. Try a sharper photo with better lighting and the full page in frame.' }, { status: 500 });
  }
}
