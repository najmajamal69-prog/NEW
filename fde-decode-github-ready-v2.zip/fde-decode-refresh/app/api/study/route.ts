import OpenAI from 'openai';
import { NextResponse } from 'next/server';
import { SUBJECTS, CLASS_LEVELS, LANGUAGES, type StudyMode } from '@/lib/study';

export const runtime = 'nodejs';
export const maxDuration = 60;

const MODES: StudyMode[] = ['tutor', 'visual', 'quiz', 'flashcards', 'formula', 'notes', 'sticky'];

function parseJson(text: string) {
  const cleaned = text.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  return JSON.parse(cleaned) as Record<string, unknown>;
}

function buildPrompt(mode: StudyMode, topic: string, subject: string, classLevel: string, language: string) {
  const common = `
Create educational material for FDE Decode.
Subject: ${subject}.
Learner level: ${classLevel}.
Output language: ${language}.
Topic entered by the student: ${JSON.stringify(topic)}.

Accuracy rules:
- Be careful, clear, age-appropriate and conceptually correct.
- Do not invent quotes, Quran references, hadith references, page numbers, syllabus claims, citations, or textbook wording.
- If a claim depends on a specific textbook edition or local syllabus, say that the student should check their own textbook.
- For Mathematics and Physics, show the working and units where relevant; check calculations before responding.
- For Biology and Chemistry, distinguish a simplified school model from a complete scientific account where relevant.
- For English and Urdu, use correct grammar, examples, and meanings. For Islamiat and Mutalia Quran, use respectful language and do not fabricate religious references.
- Make the material useful for the selected subject, not generic filler.
- If the entered topic is ambiguous, explain the most likely interpretation and mention the ambiguity briefly.
- Always return one valid JSON object and no markdown fences.
`;

  const prompts: Record<StudyMode, string> = {
    tutor: `Return JSON with exactly these keys: title (string), definition (string), simpleExplanation (string), keyPoints (array of 4-7 strings), examples (array of 2-4 strings), importantTerms (array of objects with term and meaning strings), relatedTopics (array of 3-5 strings), checkQuestions (array of 3 strings), caution (string). Explain the topic from the ground up. For subjects where a single formal definition is not appropriate, make the definition field a concise description of the topic. ${common}`,
    visual: `Return JSON with exactly these keys: title (string), visualType (one of "concept-map", "flowchart", "cycle", "comparison", "structure", "graph", "timeline"), diagramLabels (array of 4-7 short labels, each under 30 characters), explanation (string), keyPoints (array of 3-5 strings), realWorldExample (string), limitation (string). Choose a visualType that fits this topic. diagramLabels must describe meaningful stages, parts, causes, outcomes, examples, or comparisons relevant to the entered topic so the website can render a matching educational diagram. ${common}`,
    quiz: `Return JSON with exactly one key: questions. It must be an array of EXACTLY 50 multiple-choice questions (never fewer than 50). Every question object must have question (string), scenario (string; give a realistic or subject-appropriate context, passage, calculation, example, or situation), options (array of exactly 4 strings), answer (integer 0, 1, 2, or 3 indicating the correct option), explanation (string explaining why it is correct). Make the questions challenging but appropriate for the selected class. Cover different facets of the topic. Avoid duplicate questions and ambiguous options. Check all answer indexes and calculations. For English/Urdu, use sentences or passages; for Islamiat/Mutalia Quran, be respectful and avoid inventing references. ${common}`,
    flashcards: `Return JSON with exactly these keys: title (string), cards (array of EXACTLY 12 objects, each containing front and back strings), studyTip (string). Cards should test active recall and cover definitions, reasoning, examples, vocabulary, steps, distinctions, or equations as applicable. ${common}`,
    formula: `Return JSON with exactly these keys: title (string), sections (array of 3-6 objects each containing heading (string) and items (array of 2-5 objects with name, expression, meaning, example strings)), reminders (array of 3-5 strings). If the selected topic is not formula-based, provide a subject-appropriate quick reference instead: grammar rules for languages, key principles for Islamiat/Mutalia Quran, algorithm steps for Computer Science, or definitions and distinctions for Biology. Do not invent formulas where none apply. ${common}`,
    notes: `Return JSON with exactly these keys: title (string), overview (string), keyPoints (array of 5-8 strings), vocabulary (array of 3-6 objects with term and meaning strings), commonMistakes (array of 3-5 strings), recap (array of exactly 3 strings), selfCheck (array of 3 questions with short answers). ${common}`,
    sticky: `Return JSON with exactly these keys: title (string), stickyNotes (array of 10 objects with title, content, category strings), examTips (array of 3 strings). Create compact, useful topic-specific revision notes covering definitions, facts, formulas/steps, common confusions, examples and exam reminders where relevant. Never pad with repeated facts. ${common}`,
  };
  return prompts[mode];
}

export async function POST(request: Request) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return NextResponse.json(
      { error: 'AI is not configured yet. Add OPENAI_API_KEY in Netlify → Site configuration → Environment variables.' },
      { status: 503 },
    );
  }

  try {
    const body = await request.json() as {
      topic?: unknown;
      subject?: unknown;
      classLevel?: unknown;
      language?: unknown;
      mode?: unknown;
    };

    if (typeof body.topic !== 'string' || !body.topic.trim()) {
      return NextResponse.json({ error: 'Enter a topic first.' }, { status: 400 });
    }
    const topic = body.topic.trim();
    if (topic.length > 300) {
      return NextResponse.json({ error: 'Please keep the topic under 300 characters.' }, { status: 400 });
    }

    const subject = typeof body.subject === 'string' && SUBJECTS.some((item) => item.name === body.subject)
      ? body.subject
      : 'Biology';
    const classLevel = typeof body.classLevel === 'string' && CLASS_LEVELS.includes(body.classLevel)
      ? body.classLevel
      : 'Class 6';
    const language = typeof body.language === 'string' && (LANGUAGES as readonly string[]).includes(body.language)
      ? body.language
      : 'Simple English';
    const mode = typeof body.mode === 'string' && MODES.includes(body.mode as StudyMode)
      ? body.mode as StudyMode
      : 'tutor';

    const openai = new OpenAI({ apiKey });
    let data: Record<string, unknown> | undefined;
    const attempts = mode === 'quiz' || mode === 'flashcards' ? 3 : 1;

    for (let attempt = 0; attempt < attempts; attempt += 1) {
      const retryInstruction = mode === 'quiz'
        ? '\nIMPORTANT RETRY: Your previous result did not contain 50 complete questions. Return exactly 50 complete questions now.'
        : '\nIMPORTANT RETRY: Your previous result did not contain 12 complete flashcards. Return exactly 12 complete flashcards now.';
      const prompt = buildPrompt(mode, topic, subject, classLevel, language) + (attempt > 0 ? retryInstruction : '');
      const response = await openai.responses.create({
        model: process.env.OPENAI_MODEL || 'gpt-4.1-mini',
        instructions: 'You are a careful, high-quality school tutor. You must follow the requested JSON structure. Prefer correctness over confident guessing. Never claim generated material has been verified against a specific official textbook.',
        input: prompt,
        text: { format: { type: 'json_object' } },
        max_output_tokens: mode === 'quiz' ? 14000 : 5000,
      });
      if (!response.output_text) throw new Error('The AI returned an empty response.');
      data = parseJson(response.output_text);
      if (mode === 'quiz') {
        const questions = Array.isArray(data.questions) ? data.questions : [];
        if (questions.length >= 50) break;
      } else if (mode === 'flashcards') {
        const cards = Array.isArray(data.cards) ? data.cards : [];
        if (cards.length >= 12) break;
      } else {
        break;
      }
    }

    if (!data) throw new Error('No generated data was returned.');
    if (mode === 'flashcards') {
      const cards = Array.isArray(data.cards) ? data.cards : [];
      const validCards = cards.slice(0, 12).filter((item) => {
        if (!item || typeof item !== 'object') return false;
        const card = item as { front?: unknown; back?: unknown };
        return typeof card.front === 'string' && card.front.trim().length > 0 && typeof card.back === 'string' && card.back.trim().length > 0;
      });
      if (validCards.length < 12) {
        return NextResponse.json({ error: 'The AI did not return 12 complete flashcards. Please generate the deck again.' }, { status: 502 });
      }
      data.cards = validCards;
    }
    if (mode === 'quiz') {
      const questions = Array.isArray(data.questions) ? data.questions : [];
      if (questions.length < 50) {
        return NextResponse.json({ error: `The AI returned only ${questions.length} questions, not 50 complete questions. Please generate again.` }, { status: 502 });
      }
      data.questions = questions.slice(0, 50).map((item) => {
        const q = item as { question?: unknown; scenario?: unknown; options?: unknown; answer?: unknown; explanation?: unknown };
        const options = Array.isArray(q.options) ? q.options.map(String).slice(0, 4) : [];
        return {
          question: String(q.question ?? ''),
          scenario: String(q.scenario ?? ''),
          options,
          answer: Number.isInteger(q.answer) && Number(q.answer) >= 0 && Number(q.answer) < 4 ? Number(q.answer) : 0,
          explanation: String(q.explanation ?? 'Review the concept in your notes.'),
        };
      }).filter((q) => q.question && q.options.length === 4);
      if ((data.questions as unknown[]).length < 50) {
        return NextResponse.json({ error: 'Some generated questions were incomplete. Please generate the quiz again.' }, { status: 502 });
      }
    }

    return NextResponse.json({
      data,
      meta: { topic, subject, classLevel, language, mode, generatedAt: new Date().toISOString() },
    });
  } catch (error) {
    console.error('FDE Decode study API error:', error);
    return NextResponse.json(
      { error: 'The AI request could not be completed. Check your API configuration or try a shorter topic.' },
      { status: 500 },
    );
  }
}
