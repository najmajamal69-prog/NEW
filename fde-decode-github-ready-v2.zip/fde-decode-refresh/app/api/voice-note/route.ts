import OpenAI from 'openai';
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const maxDuration = 60;

export async function POST(request: Request) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return NextResponse.json({ error: 'AI is not configured. Add OPENAI_API_KEY to .env.local and your hosting environment.' }, { status: 503 });
  try {
    const form = await request.formData();
    const audio = form.get('audio');
    if (!(audio instanceof File)) return NextResponse.json({ error: 'Record or upload an audio note first.' }, { status: 400 });
    if (audio.size > 20 * 1024 * 1024) return NextResponse.json({ error: 'Audio must be smaller than 20 MB.' }, { status: 413 });
    const client = new OpenAI({ apiKey });
    const transcription = await client.audio.transcriptions.create({ file: audio, model: process.env.OPENAI_TRANSCRIPTION_MODEL || 'gpt-4o-mini-transcribe' });
    return NextResponse.json({ text: transcription.text || '' });
  } catch (error) {
    console.error('FDE Decode voice transcription error:', error);
    return NextResponse.json({ error: 'Could not transcribe the audio. Try a shorter recording and check your microphone permission.' }, { status: 500 });
  }
}
