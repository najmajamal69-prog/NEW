// Backward-compatible endpoint. The current frontend uses /api/study.
export { POST } from '../study/route';
