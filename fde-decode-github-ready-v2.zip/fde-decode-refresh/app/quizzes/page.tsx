import StudyWorkspace from '@/components/StudyWorkspace';
export default function Quizzes() { return <StudyWorkspace mode="quiz" initialSubject="Physics" />; }
