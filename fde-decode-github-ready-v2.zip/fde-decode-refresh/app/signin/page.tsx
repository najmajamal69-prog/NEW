'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { GraduationCap, Sparkles } from 'lucide-react';

export default function SignInPage() {
  const router = useRouter();
  const [mode, setMode] = useState<'signin'|'signup'>('signup');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [schoolClass, setSchoolClass] = useState('Class 9');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  function submit(e: React.FormEvent) {
    e.preventDefault(); setError('');
    const mail = email.trim().toLowerCase();
    if (!mail || !password || (mode === 'signup' && !name.trim())) { setError('Please complete all required fields.'); return; }
    try {
      const accounts = JSON.parse(localStorage.getItem('fde-demo-accounts') || '{}');
      if (mode === 'signup') {
        if (accounts[mail]) { setError('An account for this email already exists. Choose Sign in.'); return; }
        accounts[mail] = { name: name.trim(), email: mail, schoolClass, password };
        localStorage.setItem('fde-demo-accounts', JSON.stringify(accounts));
      } else {
        if (!accounts[mail] || accounts[mail].password !== password) { setError('Email or password did not match this browser demo account.'); return; }
      }
      const account = accounts[mail];
      localStorage.setItem('fde-current-email', mail);
      localStorage.setItem('fde-current-user', JSON.stringify({ name: account.name, email: account.email, schoolClass: account.schoolClass }));
      router.push('/dashboard'); router.refresh();
    } catch { setError('Could not save your account in this browser.'); }
  }
  return <main className="page-wrap inner-page" style={{maxWidth:760, margin:'0 auto'}}>
    <section className="scan-upload-card" style={{padding: 'clamp(24px,5vw,48px)', marginTop:32}}>
      <div className="flex items-center gap-3 mb-6"><span className="brand-mark"><GraduationCap size={23}/></span><div><p className="eyebrow"><Sparkles size={14}/> YOUR PERSONAL STUDY SPACE</p><h1 className="text-3xl font-black">{mode === 'signup' ? 'Create your account' : 'Welcome back'}</h1></div></div>
      <p className="mb-6 leading-7 text-[#7e867d]">Save your study history and revisit the topics you have worked on.</p>
      <form onSubmit={submit} className="grid gap-4">
        {mode === 'signup' && <label className="font-semibold text-sm">Student name<input required value={name} onChange={e=>setName(e.target.value)} className="mt-2 w-full rounded-xl border border-[#e5e5dc] bg-white p-3" placeholder="Your name" /></label>}
        <label className="font-semibold text-sm">Email<input required type="email" value={email} onChange={e=>setEmail(e.target.value)} className="mt-2 w-full rounded-xl border border-[#e5e5dc] bg-white p-3" placeholder="student@example.com" /></label>
        {mode === 'signup' && <label className="font-semibold text-sm">Class<select value={schoolClass} onChange={e=>setSchoolClass(e.target.value)} className="mt-2 w-full rounded-xl border border-[#e5e5dc] bg-white p-3">{Array.from({length:11},(_,i)=><option key={i}>Class {i+1}</option>)}</select></label>}
        <label className="font-semibold text-sm">Password<input required type="password" minLength={4} value={password} onChange={e=>setPassword(e.target.value)} className="mt-2 w-full rounded-xl border border-[#e5e5dc] bg-white p-3" placeholder="At least 4 characters" /></label>
        {error && <p role="alert" className="rounded-xl bg-[#fff0eb] p-3 text-sm text-[#a4422c]">{error}</p>}
        <button className="button button-primary mt-2 w-full justify-center" type="submit">{mode === 'signup' ? 'Create study account' : 'Sign in to FDE Decode'}</button>
      </form>
      <p className="mt-5 text-sm text-[#7e867d]">{mode === 'signup' ? 'Already have an account?' : 'New to FDE Decode?'} <button className="font-bold text-[#285d46] underline" onClick={()=>{setMode(mode==='signup'?'signin':'signup');setError('');}}>{mode==='signup'?'Sign in':'Create account'}</button></p>
      <p className="mt-6 rounded-xl bg-[#fff5d7] p-3 text-xs leading-5 text-[#826a2c]">Prototype note: this starter stores demo account details in this browser only. Do not use a real or reused password. Before public launch, connect a secure authentication provider and database for private, cross-device accounts.</p>
      <Link href="/" className="mt-5 inline-block text-sm font-semibold text-[#285d46]">← Back to home</Link>
    </section>
  </main>;
}
