import StudyWorkspace from '@/components/StudyWorkspace';
export default function SmartNotes() { return <StudyWorkspace mode="notes" initialSubject="Biology" />; }
