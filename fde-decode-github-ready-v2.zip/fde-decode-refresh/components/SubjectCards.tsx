'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowUpRight, Atom, BookOpen, Code2, Dna, FlaskConical, Moon, PenLine, Sigma } from 'lucide-react';
import { SUBJECTS } from '@/lib/study';

const icons = {
  dna: Dna,
  atom: Atom,
  code: Code2,
  flask: FlaskConical,
  book: BookOpen,
  sigma: Sigma,
  pen: PenLine,
  moon: Moon,
  'book-open': BookOpen,
} as const;

export default function SubjectCards() {
  return (
    <div className="subject-grid updated-subject-grid">
      {SUBJECTS.map((subject, index) => {
        const Icon = icons[subject.icon];
        return (
          <motion.div key={subject.slug} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.035 }} whileHover={{ y: -5 }}>
            <Link className={`subject-card ${subject.accent} subject-${subject.slug}`} href={`/subjects/${subject.slug}`}>
              <div className="subject-card-top">
                <span className="subject-icon"><Icon size={23} /></span>
                <span className="subject-tag">OPEN SUBJECT</span>
              </div>
              <h3>{subject.name}</h3>
              <p>{subject.short}</p>
              <div className="subject-footer-hint"><span>{subject.visual}</span><ArrowUpRight size={17} /></div>
            </Link>
          </motion.div>
        );
      })}
    </div>
  );
}
