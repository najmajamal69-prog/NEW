'use client';

import { motion } from 'framer-motion';

type VisualDiagramProps = {
  topic: string;
  visualType?: string;
  labels?: string[];
};

function shortLabel(value: string) {
  return value.length > 22 ? `${value.slice(0, 21)}…` : value;
}

export default function VisualDiagram({ topic, visualType = 'concept-map', labels = [] }: VisualDiagramProps) {
  const items = (labels.length ? labels : ['Main idea', 'Key parts', 'How it works', 'Example', 'Result']).slice(0, 7);
  const centre = { x: 300, y: 155 };
  const isCycle = visualType === 'cycle';
  const isFlow = visualType === 'flowchart' || visualType === 'timeline';
  const isComparison = visualType === 'comparison';
  const isGraph = visualType === 'graph';
  const isStructure = visualType === 'structure';

  const points = items.map((label, index) => {
    if (isCycle) {
      const angle = (-Math.PI / 2) + (2 * Math.PI * index) / items.length;
      return { label, x: centre.x + Math.cos(angle) * 175, y: centre.y + Math.sin(angle) * 95 };
    }
    if (isFlow) {
      const gap = 500 / Math.max(1, items.length - 1);
      return { label, x: 50 + gap * index, y: 154 + (index % 2 ? 15 : -15) };
    }
    if (isComparison) {
      const side = index % 2 === 0 ? 0 : 1;
      const row = Math.floor(index / 2);
      return { label, x: side === 0 ? 150 : 450, y: 75 + row * 72 };
    }
    const angle = (-Math.PI / 2) + (2 * Math.PI * index) / items.length;
    const radiusX = isStructure ? 190 : 205;
    const radiusY = isStructure ? 90 : 110;
    return { label, x: centre.x + Math.cos(angle) * radiusX, y: centre.y + Math.sin(angle) * radiusY };
  });

  return (
    <div className={`visual-diagram-shell visual-kind-${visualType}`}>
      <div className="visual-diagram-head">
        <span className="diagram-live-dot" />
        <span>GENERATED CONCEPT MAP</span>
        <span className="diagram-type-label">{visualType.replace('-', ' ')}</span>
      </div>
      <svg className="topic-diagram-svg" viewBox="0 0 600 310" role="img" aria-label={`Visual learning diagram for ${topic}`}>
        <defs>
          <linearGradient id="fdeNodeGradient" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#8d7aff" />
            <stop offset="100%" stopColor="#5944d1" />
          </linearGradient>
          <linearGradient id="fdeLeafGradient" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="100%" stopColor="#f2efff" />
          </linearGradient>
        </defs>
        {isGraph ? (
          <g className="graph-illustration">
            <path d="M 65 35 V 260 H 555" fill="none" stroke="#a9a0d8" strokeWidth="2" />
            {[0, 1, 2, 3, 4].map((n) => <line key={n} x1="65" y1={70 + n * 42} x2="550" y2={70 + n * 42} stroke="#e7e3f8" strokeDasharray="5 7" />)}
            <motion.path d="M 88 232 C 165 227, 187 191, 250 174 S 370 109, 420 103 S 500 64, 540 45" fill="none" stroke="#6b55e8" strokeWidth="5" strokeLinecap="round" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1.2, ease: 'easeOut' }} />
            <text x="74" y="25" fill="#6b55e8" fontSize="12" fontWeight="700">{shortLabel(items[0] ?? topic)}</text>
            <text x="448" y="287" fill="#77748e" fontSize="11">Topic relationship →</text>
            <circle cx="250" cy="174" r="7" fill="#ffac70"><title>{items[1] ?? 'Key point'}</title></circle>
            <circle cx="420" cy="103" r="7" fill="#39ad88"><title>{items[2] ?? 'Key point'}</title></circle>
          </g>
        ) : isCycle ? (
          <g>
            <ellipse cx="300" cy="155" rx="175" ry="95" fill="none" stroke="#d8d0ff" strokeWidth="2" strokeDasharray="5 7" />
            {points.map((p, i) => {
              const next = points[(i + 1) % points.length];
              return <motion.path key={`cycle-line-${i}`} d={`M ${p.x} ${p.y} Q ${centre.x} ${centre.y} ${next.x} ${next.y}`} fill="none" stroke="#b3a7ff" strokeWidth="2" strokeDasharray="6 5" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ delay: i * 0.08, duration: 0.4 }} />;
            })}
            {points.map((p, i) => <motion.g key={p.label} initial={{ opacity: 0, scale: 0.75 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.09 }}>
              <rect x={p.x - 59} y={p.y - 21} width="118" height="42" rx="13" fill="url(#fdeLeafGradient)" stroke="#dcd5ff" strokeWidth="1.5" />
              <text x={p.x} y={p.y + 4} textAnchor="middle" fill="#5140a8" fontSize="11" fontWeight="600">{shortLabel(p.label)}</text><title>{p.label}</title>
            </motion.g>)}
          </g>
        ) : isFlow ? (
          <g>
            {points.slice(0, -1).map((p, i) => <motion.path key={`flowline-${i}`} d={`M ${p.x + 52} ${p.y} H ${points[i + 1].x - 52}`} stroke="#b1a4ff" strokeWidth="2.5" fill="none" strokeLinecap="round" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ delay: i * 0.1, duration: 0.35 }} />)}
            {points.map((p, i) => <motion.g key={p.label} initial={{ y: 12, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: i * 0.08 }}>
              <rect x={p.x - 48} y={p.y - 30} width="96" height="60" rx="13" fill={i === 0 ? 'url(#fdeNodeGradient)' : 'url(#fdeLeafGradient)'} stroke={i === 0 ? '#6b55e8' : '#dcd5ff'} />
              <text x={p.x} y={p.y - 2} textAnchor="middle" fill={i === 0 ? '#fff' : '#5140a8'} fontSize="10" fontWeight="700">{String(i + 1).padStart(2, '0')}</text>
              <text x={p.x} y={p.y + 14} textAnchor="middle" fill={i === 0 ? '#fff' : '#5140a8'} fontSize="9.5">{shortLabel(p.label)}</text><title>{p.label}</title>
            </motion.g>)}
          </g>
        ) : isComparison ? (
          <g>
            <rect x="40" y="30" width="220" height="250" rx="18" fill="#f0edff" stroke="#ded7ff" />
            <rect x="340" y="30" width="220" height="250" rx="18" fill="#e9f8f2" stroke="#cdeede" />
            <text x="150" y="55" textAnchor="middle" fill="#5b49c4" fontSize="12" fontWeight="800">SIDE A</text>
            <text x="450" y="55" textAnchor="middle" fill="#27885f" fontSize="12" fontWeight="800">SIDE B</text>
            {points.map((p, i) => {
              const sideA = i % 2 === 0;
              const row = Math.floor(i / 2);
              const x = sideA ? 150 : 450;
              const y = 94 + row * 64;
              return <motion.g key={p.label} initial={{ opacity: 0, x: sideA ? -8 : 8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.07 }}>
                <rect x={x - 85} y={y - 19} width="170" height="38" rx="11" fill="#fff" stroke={sideA ? '#d9d0ff' : '#c9ead9'} />
                <text x={x} y={y + 4} textAnchor="middle" fontSize="10.5" fill={sideA ? '#5546ad' : '#287d59'} fontWeight="600">{shortLabel(p.label)}</text><title>{p.label}</title>
              </motion.g>;
            })}
          </g>
        ) : (
          <g>
            {points.map((p, i) => <motion.path key={`link-${i}`} d={`M ${centre.x} ${centre.y} Q ${(centre.x + p.x) / 2} ${(centre.y + p.y) / 2 - 8} ${p.x} ${p.y}`} stroke={isStructure ? '#ffbd91' : '#c8c0f8'} strokeWidth="2" fill="none" strokeDasharray="5 5" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ delay: i * 0.06, duration: 0.45 }} />)}
            {points.map((p, i) => <motion.g key={p.label} initial={{ opacity: 0, scale: 0.7 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.15 + i * 0.08, type: 'spring', stiffness: 150 }}>
              <circle cx={p.x} cy={p.y} r="40" fill={isStructure ? '#fff0e5' : '#fff'} stroke={isStructure ? '#ffd2b4' : '#dcd5ff'} strokeWidth="1.5" />
              <text x={p.x} y={p.y + 4} textAnchor="middle" fontSize="10" fontWeight="650" fill={isStructure ? '#9a5930' : '#5e50b3'}>{shortLabel(p.label)}</text><title>{p.label}</title>
            </motion.g>)}
            <motion.circle cx={centre.x} cy={centre.y} r="60" fill="url(#fdeNodeGradient)" initial={{ scale: 0.75 }} animate={{ scale: [0.95, 1, 0.98] }} transition={{ duration: 2.5, repeat: Infinity, repeatType: 'reverse' }} />
            <text x={centre.x} y={centre.y - 1} textAnchor="middle" fontSize="13" fontWeight="800" fill="#fff">{shortLabel(topic)}</text>
            <text x={centre.x} y={centre.y + 17} textAnchor="middle" fontSize="9" fill="#f5f2ff">CORE TOPIC</text>
          </g>
        )}
      </svg>
      <div className="diagram-caption"><span>AI-generated learning aid</span><span>Check labels against your textbook when precision matters.</span></div>
    </div>
  );
}
