'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { BookOpen, BrainCircuit, ChartNoAxesCombined, FileText, FlaskConical, GraduationCap, Layers3, Menu, Orbit, X, Camera, StickyNote } from 'lucide-react';
import { useState } from 'react';

const links = [
  { href: '/', label: 'Home', icon: Orbit },
  { href: '/dashboard', label: 'Dashboard', icon: ChartNoAxesCombined },
  { href: '/subjects', label: 'Subjects', icon: BookOpen },
  { href: '/visual-learning', label: 'Visual Lab', icon: FlaskConical },
  { href: '/quizzes', label: 'Quizzes', icon: BrainCircuit },
  { href: '/flashcards', label: 'Flashcards', icon: Layers3 },
  { href: '/notes', label: 'AI Notes', icon: FileText },
  { href: '/scan-notes', label: 'Scan Notes', icon: Camera },
  { href: '/sticky-notes', label: 'Sticky Notes', icon: StickyNote },
  { href: '/formulas', label: 'Quick Reference', icon: GraduationCap },
];

export default function Navbar() {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  return (
    <header className="topbar">
      <Link href="/" className="brand"><span className="brand-mark">F</span><span>FDE <b>Decode</b><small>YOUR AI STUDY HELPER</small></span></Link>
      <button className="mobile-menu" onClick={() => setOpen(!open)} aria-label="Toggle menu">{open ? <X /> : <Menu />}</button>
      <nav className={open ? 'nav-links nav-open' : 'nav-links'}>
        {links.map(({ href, label, icon: Icon }) => {
          const active = href === '/' ? path === '/' : path === href || path.startsWith(`${href}/`);
          return <Link key={href} href={href} onClick={() => setOpen(false)} className={active ? 'nav-link active' : 'nav-link'}><Icon size={16}/>{label}</Link>;
        })}
      </nav>
      <Link href="/dashboard" className="profile-chip"><span className="profile-avatar">AI</span><span>My progress</span></Link>
    </header>
  );
}
