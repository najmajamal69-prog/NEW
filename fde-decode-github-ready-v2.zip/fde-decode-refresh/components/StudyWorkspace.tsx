'use client';

import { useState } from 'react';
import type { FormEvent } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowRight, BookOpen, CheckCircle2, ChevronDown, CircleHelp, ClipboardList, FileText, FlaskConical, LoaderCircle, RefreshCw, Sparkles, WandSparkles } from 'lucide-react';
import FlashcardDeck from '@/components/FlashcardDeck';
import VisualDiagram from '@/components/VisualDiagram';
import { CLASS_LEVELS, LANGUAGES, SUBJECTS, type QuizQuestion, type StudyCard, type StudyMode } from '@/lib/study';

type Generated = Record<string, unknown>;

type WorkspaceProps = {
  mode: StudyMode;
  initialSubject?: string;
  lockedSubject?: boolean;
  compact?: boolean;
};

const MODE_COPY: Record<StudyMode, { eyebrow: string; title: string; description: string; button: string; placeholder: string }> = {
  tutor: { eyebrow: 'AI TOPIC EXPLORER', title: 'Understand any topic.', description: 'Enter a topic to get a definition, clear explanation, examples, important terms, and quick checks — all tailored to your selected class and subject.', button: 'Explain this topic', placeholder: 'e.g. Photosynthesis, noun clauses, quadratic equations…' },
  visual: { eyebrow: 'AI VISUAL LAB', title: 'Turn a topic into a visual.', description: 'Enter a topic and get a topic-specific diagram, visual labels, a simple explanation, and the key relationships to remember.', button: 'Build my visual', placeholder: 'e.g. Water cycle, Newton’s laws, cell structure…' },
  quiz: { eyebrow: 'AI QUIZ BUILDER', title: 'Practise with 50 questions.', description: 'Generate exactly 50 concept-based MCQs with contextual scenarios, four options, answers, and explanations. The app will not show a shorter quiz.', button: 'Generate 50-question quiz', placeholder: 'e.g. Motion and speed, fractions, active and passive voice…' },
  flashcards: { eyebrow: 'AI FLASHCARD STUDIO', title: 'Make recall feel effortless.', description: 'Generate a fresh deck for any subject and topic. Flip cards in 3D, move with animated transitions, and mark the ideas you know.', button: 'Generate flashcards', placeholder: 'e.g. Parts of a cell, chemical bonding, Urdu grammar…' },
  formula: { eyebrow: 'AI QUICK REFERENCE', title: 'Build your topic sheet.', description: 'Get a focused quick-reference sheet with formulas where they apply, symbol meanings, rules, examples, and reminders for your subject.', button: 'Create my reference sheet', placeholder: 'e.g. Equations of motion, algebraic identities, tenses…' },
  notes: { eyebrow: 'AI SMART NOTES', title: 'Turn a topic into clear notes.', description: 'Generate a concise overview, key points, vocabulary, common mistakes, recap and self-check questions for the topic you choose.', button: 'Generate study notes', placeholder: 'e.g. Ecosystems, algorithms, rights and responsibilities…' },
  sticky: { eyebrow: 'SMART STICKY NOTES', title: 'Keep the key ideas close.', description: 'Generate a topic-specific set of colourful revision notes with definitions, facts, formulas, common confusions and exam reminders.', button: 'Make sticky notes', placeholder: 'e.g. Work and energy, cell structure, HTML forms…' },
};

function asStrings(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((item) => typeof item === 'string').map(String) : [];
}
function asRecords(value: unknown): Record<string, unknown>[] {
  return Array.isArray(value) ? value.filter((item): item is Record<string, unknown> => Boolean(item) && typeof item === 'object') : [];
}
function asText(value: unknown, fallback = ''): string {
  return typeof value === 'string' ? value : fallback;
}

function QuizResults({ questions }: { questions: QuizQuestion[] }) {
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [submitted, setSubmitted] = useState(false);
  const score = questions.reduce((total, question, index) => total + (answers[index] === question.answer ? 1 : 0), 0);
  const answeredCount = Object.keys(answers).length;

  function reset() { setAnswers({}); setSubmitted(false); }

  return (
    <div className="generated-quiz-results">
      <div className="generated-quiz-summary">
        <div><span className="eyebrow">YOUR GENERATED QUIZ</span><h2>50-question practice set</h2><p>Choose one answer per question, then check your work to see the explanations.</p></div>
        <div className="quiz-total-pill"><ClipboardList size={17} /> {questions.length} questions</div>
      </div>
      <div className="quiz-progress-track"><motion.span animate={{ width: `${(answeredCount / questions.length) * 100}%` }} /></div>
      <div className="generated-quiz-list">
        {questions.map((question, index) => (
          <motion.section className="generated-question-card" key={`${index}-${question.question}`} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(index * 0.025, 0.3) }}>
            <div className="generated-question-top"><span>QUESTION {String(index + 1).padStart(2, '0')}</span><span>{index + 1} / {questions.length}</span></div>
            {question.scenario && <div className="generated-scenario"><b>CONTEXT</b><p>{question.scenario}</p></div>}
            <h3>{question.question}</h3>
            <div className="generated-answer-grid">
              {question.options.map((option, optionIndex) => {
                const chosen = answers[index] === optionIndex;
                const correct = submitted && question.answer === optionIndex;
                const wrongChosen = submitted && chosen && question.answer !== optionIndex;
                return <motion.button key={`${index}-${optionIndex}`} type="button" disabled={submitted} onClick={() => setAnswers((old) => ({ ...old, [index]: optionIndex }))} whileHover={!submitted ? { y: -2 } : undefined} whileTap={!submitted ? { scale: 0.99 } : undefined} className={`generated-answer-option ${chosen ? 'selected' : ''} ${correct ? 'correct' : ''} ${wrongChosen ? 'wrong' : ''}`}>
                  <span>{String.fromCharCode(65 + optionIndex)}</span>{option}
                </motion.button>;
              })}
            </div>
            {submitted && <div className={`generated-explanation ${answers[index] === question.answer ? 'is-correct' : ''}`}><b>{answers[index] === question.answer ? 'Correct — well done!' : 'Review the explanation'}</b><p>{question.explanation}</p></div>}
          </motion.section>
        ))}
      </div>
      <div className="generated-quiz-actions">
        {submitted ? <>
          <div className="generated-score"><CheckCircle2 size={21} /><span><small>YOUR SCORE</small><b>{score} / {questions.length} ({Math.round(score / questions.length * 100)}%)</b></span></div>
          <button className="button button-secondary" type="button" onClick={reset}><RefreshCw size={16} /> Try again</button>
        </> : <button className="button button-primary" type="button" disabled={answeredCount !== questions.length} onClick={() => setSubmitted(true)}>Check all answers <CheckCircle2 size={17} /></button>}
      </div>
      {submitted && <motion.div className="quiz-result-note" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>{score === questions.length ? 'Excellent — every answer is correct.' : 'Read the explanations for missed questions, then try the quiz again.'}</motion.div>}
    </div>
  );
}

export default function StudyWorkspace({ mode, initialSubject, lockedSubject = false, compact = false }: WorkspaceProps) {
  const copy = MODE_COPY[mode];
  const [subject, setSubject] = useState(initialSubject ?? SUBJECTS[0].name);
  const [classLevel, setClassLevel] = useState('Class 6');
  const [language, setLanguage] = useState<(typeof LANGUAGES)[number]>('Simple English');
  const [topic, setTopic] = useState('');
  const [data, setData] = useState<Generated | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function generate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!topic.trim()) { setError('Enter a topic first, then the AI can build your learning material.'); return; }
    setLoading(true); setError(''); setData(null);
    try {
      const response = await fetch('/api/study', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic: topic.trim(), subject, classLevel, language, mode }),
      });
      const payload = await response.json() as { data?: Generated; error?: string };
      if (!response.ok || !payload.data) throw new Error(payload.error || 'Could not generate study material. Try again.');
      setData(payload.data);
      try {
        const email = localStorage.getItem('fde-current-email');
        if (email) {
          const key = `fde-progress-${email.toLowerCase()}`;
          const old = JSON.parse(localStorage.getItem(key) || '{"topics":[]}');
          const entry = { topic: topic.trim(), subject, classLevel, language, mode, studiedAt: new Date().toISOString(), title: String(payload.data.title || topic.trim()) };
          old.topics = [entry, ...(Array.isArray(old.topics) ? old.topics.filter((item: any) => !(item.topic === entry.topic && item.mode === entry.mode && item.subject === entry.subject)) : [])].slice(0, 200);
          localStorage.setItem(key, JSON.stringify(old));
        }
      } catch { /* Progress storage is best-effort in this browser prototype. */ }
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  const quizQuestions = asRecords(data?.questions).map((question) => ({
    question: asText(question.question),
    scenario: asText(question.scenario),
    options: asStrings(question.options),
    answer: typeof question.answer === 'number' ? question.answer : 0,
    explanation: asText(question.explanation, 'Review the topic and try again.'),
  })).filter((question) => question.question && question.options.length === 4) as QuizQuestion[];

  const cards = asRecords(data?.cards).map((card) => ({ front: asText(card.front), back: asText(card.back) })).filter((card) => card.front && card.back) as StudyCard[];

  return (
    <main className={`page-wrap inner-page workspace-page ${compact ? 'workspace-compact' : ''}`}>
      <motion.section className="workspace-hero" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
        <div className="workspace-hero-copy">
          <span className="eyebrow"><Sparkles size={14} /> {copy.eyebrow}</span>
          <h1>{copy.title}</h1>
          <p>{copy.description}</p>
          <div className="workspace-assurance"><span className="assurance-dot" /> AI-generated learning material • tailored to your selections</div>
        </div>
        <div className="workspace-hero-art" aria-hidden="true"><div className="workspace-art-orbit orbit-a"/><div className="workspace-art-orbit orbit-b"/><div className="workspace-art-core"><WandSparkles size={40}/></div><span className="workspace-art-chip chip-a">Your topic</span><span className="workspace-art-chip chip-b">Your level</span></div>
      </motion.section>

      <form className="topic-input-panel" onSubmit={generate}>
        <div className="topic-input-heading"><div className="topic-input-icon"><CircleHelp size={20}/></div><div><span className="eyebrow">MAKE IT YOURS</span><h2>What do you want to learn?</h2><p>Enter your own topic. You are not limited to preset chapters.</p></div></div>
        <label className="topic-field-label" htmlFor={`topic-${mode}`}>TOPIC</label>
        <textarea id={`topic-${mode}`} value={topic} onChange={(event) => setTopic(event.target.value)} maxLength={300} rows={2} placeholder={copy.placeholder} />
        <div className="topic-char-count">{topic.length}/300 characters</div>
        <div className="topic-settings-grid">
          <label><span>Subject</span><div className="select-wrap"><select value={subject} onChange={(event) => setSubject(event.target.value)} disabled={lockedSubject}>{SUBJECTS.map((item) => <option key={item.slug} value={item.name}>{item.name}</option>)}</select><ChevronDown size={16}/></div>{lockedSubject && <small>Opened from this subject's page</small>}</label>
          <label><span>Class level</span><div className="select-wrap"><select value={classLevel} onChange={(event) => setClassLevel(event.target.value)}>{CLASS_LEVELS.map((level) => <option key={level}>{level}</option>)}</select><ChevronDown size={16}/></div></label>
          <label><span>Explanation language</span><div className="select-wrap"><select value={language} onChange={(event) => setLanguage(event.target.value as (typeof LANGUAGES)[number])}>{LANGUAGES.map((value) => <option key={value}>{value}</option>)}</select><ChevronDown size={16}/></div></label>
        </div>
        <div className="topic-form-bottom"><p><BookOpen size={15}/> Subject-specific explanations and examples</p><motion.button type="submit" disabled={loading || !topic.trim()} className="button button-primary" whileHover={!loading ? { y: -2 } : undefined} whileTap={!loading ? { scale: 0.98 } : undefined}>{loading ? <><LoaderCircle size={17} className="spin-icon"/> Building your content…</> : <>{copy.button} <ArrowRight size={17}/></>}</motion.button></div>
      </form>

      {error && <motion.div className="workspace-error" role="alert" initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }}><CircleHelp size={18}/><span>{error}</span></motion.div>}
      {loading && <div className="workspace-loading" role="status"><div className="loading-orb"><WandSparkles size={28}/></div><h2>Building your learning material</h2><p>Creating {mode === 'quiz' ? '50 questions and explanations' : mode === 'visual' ? 'a topic-specific visual' : mode === 'flashcards' ? 'your animated flashcard deck' : 'topic-specific content'} for {subject} · {classLevel}.</p><div className="loading-line"><span/></div></div>}

      <AnimatePresence mode="wait">
        {data && !loading && <motion.section className="workspace-results" key={`${mode}-${topic}-${subject}`} initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.28 }}>
          <div className="results-heading"><div><span className="eyebrow">YOUR LEARNING MATERIAL</span><h2>{asText(data.title, topic)}</h2><p>{subject} · {classLevel} · {language}</p></div><span className="ai-created-pill"><Sparkles size={14}/> AI generated</span></div>

          {mode === 'tutor' && <div className="topic-explanation-layout">
            <article className="result-card definition-card"><span className="result-card-label">DEFINITION</span><p className="definition-text">{asText(data.definition, 'Explore the topic below.')}</p></article>
            <article className="result-card wide-result-card"><span className="result-card-label">EXPLAINED SIMPLY</span><p>{asText(data.simpleExplanation)}</p></article>
            <article className="result-card"><span className="result-card-label">KEY POINTS</span><ul className="result-list">{asStrings(data.keyPoints).map((value, index) => <li key={index}><CheckCircle2 size={16}/><span>{value}</span></li>)}</ul></article>
            <article className="result-card"><span className="result-card-label">EXAMPLES</span><ul className="result-list example-list">{asStrings(data.examples).map((value, index) => <li key={index}><span className="example-number">{index + 1}</span><span>{value}</span></li>)}</ul></article>
            <article className="result-card"><span className="result-card-label">IMPORTANT TERMS</span><div className="term-grid">{asRecords(data.importantTerms).map((term, index) => <div className="term-item" key={index}><b>{asText(term.term)}</b><p>{asText(term.meaning)}</p></div>)}</div></article>
            <article className="result-card"><span className="result-card-label">RELATED TOPICS</span><div className="related-topic-chips">{asStrings(data.relatedTopics).map((value, index) => <button key={index} type="button" onClick={() => { setTopic(value); setData(null); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>{value} <ArrowRight size={13}/></button>)}</div></article>
            <article className="result-card wide-result-card"><span className="result-card-label">CHECK YOUR UNDERSTANDING</span><ol className="check-question-list">{asStrings(data.checkQuestions).map((value, index) => <li key={index}>{value}</li>)}</ol></article>
          </div>}

          {mode === 'visual' && <div className="visual-result-grid"><VisualDiagram topic={topic} visualType={asText(data.visualType, 'concept-map')} labels={asStrings(data.diagramLabels)}/><article className="result-card visual-explanation-card"><span className="result-card-label">HOW TO READ THIS VISUAL</span><p>{asText(data.explanation)}</p><ul className="result-list">{asStrings(data.keyPoints).map((value, index) => <li key={index}><CheckCircle2 size={16}/><span>{value}</span></li>)}</ul><div className="real-life-box"><b>Real-world connection</b><p>{asText(data.realWorldExample)}</p></div>{asText(data.limitation) && <small className="visual-limitation">Model note: {asText(data.limitation)}</small>}</article></div>}

          {mode === 'quiz' && <QuizResults key={`${topic}-${subject}-${classLevel}`} questions={quizQuestions}/>}
          {mode === 'flashcards' && <><FlashcardDeck key={`${topic}-${subject}-${classLevel}`} cards={cards}/><div className="study-tip-strip"><Sparkles size={17}/><span>{asText(data.studyTip, 'Try to answer each card before flipping it. Revisit difficult cards later.')}</span></div></>}
          {mode === 'formula' && <div className="generated-reference-grid">{asRecords(data.sections).map((section, index) => <article className="generated-reference-card" key={index}><span className="result-card-label">QUICK REFERENCE {String(index + 1).padStart(2, '0')}</span><h3>{asText(section.heading)}</h3><div className="generated-reference-items">{asRecords(section.items).map((item, itemIndex) => <div key={itemIndex} className="generated-reference-item"><b>{asText(item.name)}</b><code>{asText(item.expression)}</code><p>{asText(item.meaning)}</p>{asText(item.example) && <small>Example: {asText(item.example)}</small>}</div>)}</div></article>)}<article className="generated-reference-card reminder-card"><h3>Remember these</h3><ul className="result-list">{asStrings(data.reminders).map((value, index) => <li key={index}><CheckCircle2 size={16}/><span>{value}</span></li>)}</ul></article></div>}
          {mode === 'sticky' && <><div className="sticky-notes-grid">{asRecords(data.stickyNotes).map((note, index) => <article className={`topic-sticky-note sticky-tone-${index % 5}`} key={index}><span className="sticky-note-pin"/><span className="sticky-note-category">{asText(note.category, 'QUICK REVISION')}</span><h3>{asText(note.title, `Key point ${index + 1}`)}</h3><p>{asText(note.content)}</p></article>)}</div><article className="result-card sticky-exam-tips"><span className="result-card-label">EXAM TIPS</span><ul className="result-list">{asStrings(data.examTips).map((tip, index) => <li key={index}><CheckCircle2 size={16}/><span>{tip}</span></li>)}</ul></article></>}
          {mode === 'notes' && <div className="smart-notes-grid"><article className="result-card wide-result-card"><span className="result-card-label">OVERVIEW</span><p>{asText(data.overview)}</p></article><article className="result-card"><span className="result-card-label">KEY POINTS</span><ul className="result-list">{asStrings(data.keyPoints).map((value, index) => <li key={index}><CheckCircle2 size={16}/><span>{value}</span></li>)}</ul></article><article className="result-card"><span className="result-card-label">COMMON MISTAKES</span><ul className="result-list">{asStrings(data.commonMistakes).map((value, index) => <li key={index}><CircleHelp size={16}/><span>{value}</span></li>)}</ul></article><article className="result-card"><span className="result-card-label">VOCABULARY</span>{asRecords(data.vocabulary).map((item, index) => <div key={index} className="term-item"><b>{asText(item.term)}</b><p>{asText(item.meaning)}</p></div>)}</article><article className="result-card"><span className="result-card-label">3-POINT RECAP</span><ol className="check-question-list">{asStrings(data.recap).map((value, index) => <li key={index}>{value}</li>)}</ol></article><article className="result-card wide-result-card"><span className="result-card-label">SELF-CHECK</span><div className="self-check-grid">{asRecords(data.selfCheck).map((item, index) => <details key={index}><summary>{asText(item.question)}</summary><p>{asText(item.answer)}</p></details>)}</div></article></div>}

          <div className="generated-content-disclaimer"><FileText size={16}/><span>AI-generated learning support can make mistakes and is not guaranteed to match every textbook edition. Double-check important facts, formulas, translations and syllabus requirements with your teacher or textbook.</span></div>
          <button type="button" className="button button-secondary generate-again-button" onClick={() => { setData(null); setError(''); window.scrollTo({ top: 0, behavior: 'smooth' }); }}><RefreshCw size={15}/> Try another topic</button>
        </motion.section>}
      </AnimatePresence>
    </main>
  );
}
