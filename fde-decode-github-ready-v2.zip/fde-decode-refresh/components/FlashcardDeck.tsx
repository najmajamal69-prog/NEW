'use client';

import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowLeft, ArrowRight, CheckCircle2, RotateCw, Sparkles } from 'lucide-react';
import type { StudyCard } from '@/lib/study';

export default function FlashcardDeck({ cards }: { cards: StudyCard[] }) {
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [known, setKnown] = useState<number[]>([]);
  const safeCards = cards.length ? cards : [{ front: 'No cards yet', back: 'Generate a flashcard set by entering a topic above.' }];
  const card = safeCards[index] ?? safeCards[0];

  function move(direction: number) {
    setFlipped(false);
    setIndex((current) => (current + direction + safeCards.length) % safeCards.length);
  }

  function markKnown() {
    setKnown((old) => old.includes(index) ? old : [...old, index]);
    move(1);
  }

  return (
    <section className="generated-flashcards" aria-label="Interactive flashcards">
      <div className="generated-flashcard-topline">
        <span>Card <b>{index + 1}</b> of {safeCards.length}</span>
        <span className="mastery-pill"><CheckCircle2 size={14} /> {known.length} mastered</span>
      </div>

      <div className="generated-flashcard-stage">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={index}
            className="study-flip-wrap"
            initial={{ opacity: 0, x: 45, rotateY: -8, scale: 0.98 }}
            animate={{ opacity: 1, x: 0, rotateY: 0, scale: 1 }}
            exit={{ opacity: 0, x: -45, rotateY: 8, scale: 0.98 }}
            transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
          >
            <motion.div
              className="study-flip-inner"
              animate={{ rotateY: flipped ? 180 : 0 }}
              transition={{ type: 'spring', stiffness: 170, damping: 20, mass: 0.8 }}
              onClick={() => setFlipped((value) => !value)}
              role="button"
              tabIndex={0}
              aria-label={flipped ? 'Show question' : 'Reveal answer'}
              onKeyDown={(event) => {
                if (event.key === 'Enter' || event.key === ' ') {
                  event.preventDefault();
                  setFlipped((value) => !value);
                }
              }}
            >
              <div className="study-flip-face study-flip-front">
                <span className="study-card-kicker"><Sparkles size={14} /> QUESTION</span>
                <span className="study-card-text">{card.front}</span>
                <span className="study-card-hint"><RotateCw size={15} /> Tap to reveal answer</span>
              </div>
              <div className="study-flip-face study-flip-back">
                <span className="study-card-kicker"><CheckCircle2 size={14} /> ANSWER</span>
                <span className="study-card-text">{card.back}</span>
                <span className="study-card-hint"><RotateCw size={15} /> Tap to see question</span>
              </div>
            </motion.div>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="generated-flashcard-controls">
        <motion.button type="button" className="button button-secondary" onClick={() => move(-1)} whileHover={{ x: -3, y: -2 }} whileTap={{ scale: 0.95 }}>
          <ArrowLeft size={16} /> Previous
        </motion.button>
        <motion.button type="button" className="button button-primary" onClick={markKnown} whileHover={{ y: -3, boxShadow: '0 12px 28px #6b55e855' }} whileTap={{ scale: 0.96 }}>
          <CheckCircle2 size={16} /> I know this
        </motion.button>
        <motion.button type="button" className="button button-secondary" onClick={() => move(1)} whileHover={{ x: 3, y: -2 }} whileTap={{ scale: 0.95 }}>
          Next <ArrowRight size={16} />
        </motion.button>
      </div>

      <div className="generated-flashcard-progress" aria-label={`Card ${index + 1} of ${safeCards.length}`}>
        <motion.span animate={{ width: `${((index + 1) / safeCards.length) * 100}%` }} transition={{ duration: 0.35 }} />
      </div>
      <div className="generated-flashcard-dots">
        {safeCards.map((_, itemIndex) => (
          <motion.button
            key={itemIndex}
            type="button"
            aria-label={`Go to flashcard ${itemIndex + 1}`}
            className={`${itemIndex === index ? 'current' : ''} ${known.includes(itemIndex) ? 'mastered' : ''}`}
            onClick={() => { setIndex(itemIndex); setFlipped(false); }}
            animate={{ width: itemIndex === index ? 24 : 8, scale: itemIndex === index ? 1.05 : 1 }}
            whileHover={{ scale: 1.35 }}
            whileTap={{ scale: 0.8 }}
            transition={{ duration: 0.2 }}
          />
        ))}
      </div>
    </section>
  );
}
