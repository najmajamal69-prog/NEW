'use client';
import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { MessageSquareText, Star, X } from 'lucide-react';

export default function ReviewPrompt() {
  const [open, setOpen] = useState(false);
  const [rating, setRating] = useState(0);
  const [suggestion, setSuggestion] = useState('');
  const [saved, setSaved] = useState(false);
  useEffect(() => {
    if (localStorage.getItem('fde-review-dismissed') || localStorage.getItem('fde-review-submitted')) return;
    let shown = false;
    const show = () => { if (shown) return; shown = true; setOpen(true); cleanup(); };
    const timer = window.setTimeout(show, 45000);
    const onMouseLeave = (event: MouseEvent) => { if (event.clientY <= 0) show(); };
    const cleanup = () => { window.clearTimeout(timer); document.removeEventListener('mouseout', onMouseLeave); };
    document.addEventListener('mouseout', onMouseLeave);
    return cleanup;
  }, []);
  function close() { localStorage.setItem('fde-review-dismissed','1'); setOpen(false); }
  function submit() {
    if (!rating) return;
    const existing = JSON.parse(localStorage.getItem('fde-feedback') || '[]');
    existing.push({ rating, suggestion: suggestion.trim(), page: window.location.pathname, createdAt: new Date().toISOString() });
    localStorage.setItem('fde-feedback', JSON.stringify(existing));
    localStorage.setItem('fde-review-submitted','1');
    setSaved(true);
    window.setTimeout(() => setOpen(false), 1700);
  }
  return <AnimatePresence>{open&&<motion.div className="review-overlay" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onMouseDown={e=>{if(e.target===e.currentTarget)close();}}><motion.section className="review-modal" initial={{opacity:0,y:18,scale:.97}} animate={{opacity:1,y:0,scale:1}} exit={{opacity:0,y:10,scale:.98}} role="dialog" aria-modal="true" aria-labelledby="review-title"><div className="flex items-start justify-between gap-3"><div><span className="eyebrow"><MessageSquareText size={14}/> HELP US MAKE IT BETTER</span><h2 id="review-title" className="mt-2 text-2xl font-black">How was your study session?</h2><p className="mt-2 text-sm leading-6 text-[#7d857c]">Your feedback helps us improve FDE Decode for students.</p></div><button onClick={close} aria-label="Close feedback" className="rounded-xl p-2 hover:bg-[#f0f0e8]"><X size={19}/></button></div>{saved?<div className="mt-7 rounded-2xl bg-[#e9f6eb] p-5 font-bold text-[#285d46]">Thank you! Your feedback has been saved on this device. 💚</div>:<><div className="review-stars" aria-label="Rate from 1 to 5">{[1,2,3,4,5].map(n=><button key={n} type="button" onClick={()=>setRating(n)} className={rating>=n?'chosen':''} aria-label={`${n} star${n>1?'s':''}`}><Star size={21} fill={rating>=n?'currentColor':'none'}/></button>)}</div><label className="mb-2 block text-sm font-bold" htmlFor="review-suggestion">What worked well, or what needs fixing?</label><textarea id="review-suggestion" value={suggestion} onChange={e=>setSuggestion(e.target.value)} maxLength={1000} placeholder="Tell us about a bug, confusing section, or feature you would like…"/><p className="review-note">This version saves feedback in this browser only; it does not send it to a central admin dashboard.</p><div className="review-actions"><button className="button button-ghost" onClick={close}>Maybe later</button><button className="button button-primary" onClick={submit} disabled={!rating}>Submit feedback</button></div></>}</motion.section></motion.div>}</AnimatePresence>;
}
