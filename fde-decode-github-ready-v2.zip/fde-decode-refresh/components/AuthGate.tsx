'use client';
import { useEffect, useState } from 'react';
import { usePathname, useRouter } from 'next/navigation';

export default function AuthGate({ children }: { children: React.ReactNode }) {
  const path = usePathname(); const router = useRouter(); const [ready, setReady] = useState(false);
  useEffect(() => {
    if (path === '/signin') { setReady(true); return; }
    const email = localStorage.getItem('fde-current-email');
    if (!email) { router.replace('/signin'); return; }
    setReady(true);
  }, [path, router]);
  if (!ready) return <main className="page-wrap inner-page"><div className="scan-upload-card">Loading your study space…</div></main>;
  return <>{children}</>;
}
