# FDE Decode — Dynamic AI Study Helper

A Next.js + TypeScript educational site for Classes 1–11. Students can choose Biology, Physics, Computer Science, Chemistry, English, Mathematics, Urdu, Islamiat or Mutalia Quran, enter any topic, and generate topic-specific learning material.

## Features

- Responsive home page, dashboard and subject library.
- Individual pages for each subject with a topic input.
- Independent AI workspaces for explanations, Visual Lab, quizzes, animated flashcards, quick-reference sheets and revision notes.
- Class 1–11 and English / Urdu / Roman Urdu selectors.
- Visual Lab renders an animated SVG diagram from the AI-created topic labels and visual type.
- Quizzes are generated as 50 MCQs with four options, contextual scenarios, answer checking, explanations and score feedback. The backend rejects quiz results with fewer than 50 complete questions.
- Flashcards have animated 3D flips, smooth next/previous transitions, progress and mastered-card tracking.
- Handwritten-note image scanning uses a vision-capable model and flags uncertain text.
- Voice-note recording and server-side speech transcription.
- Sign-in / profile prototype and per-profile study history dashboard.
- Exit-intent / timed review prompt for rating and suggestions.
- API keys are read on the server only.

## Run locally

Use a current Node.js LTS release. Open this project directory in a terminal, then run:

```bash
npm install
```

Create `.env.local` in the project root (do not upload it to GitHub):

```env
OPENAI_API_KEY=your_real_api_key_here
OPENAI_MODEL=gpt-4.1-mini
```

Then start the site:

```bash
npm run dev
```

Visit `http://localhost:3000`.

## GitHub and Netlify

1. Upload the contents of this project folder into your GitHub repository, allowing files at the same paths to be replaced.
2. Commit the changes.
3. In Netlify, connect or open the site linked to that repository.
4. In **Site configuration → Environment variables**, add `OPENAI_API_KEY` and optionally `OPENAI_MODEL`.
5. Redeploy the site after saving the environment variables.

Never upload `.env.local`, API keys, or secret tokens. `.gitignore` blocks local environment files.

## Sign-in and student progress note

The included sign-in is a **local prototype only**: it stores demo account records and study history in the current browser. It is useful for testing the UI, but it is not secure authentication and does not sync across devices. Before inviting real students, replace it with Supabase Auth, Firebase Auth, or another secure authentication provider and store profiles, progress, feedback and saved notes in a protected database. Do not use real or reused passwords in the prototype.

## Accuracy and content limits

The AI can explain student-entered topics dynamically, but it is not guaranteed to be correct and is not connected to a verified, searchable database of all official FDE/NBF textbooks. Check high-stakes school facts, calculations, religious references, translations and syllabus requirements against the student's book or teacher's guidance. The Visual Lab makes topic-specific schematic SVG learning diagrams; it does not currently generate photorealistic or custom AI image files. Voice transcription and handwritten recognition can make mistakes, so students should review the result against the original.
